#One way ANOVA with R by Alejandro Moltó

#Loading libraries:
library(readr)
library(ggplot2)
library(dplyr)
library(multcompView)
library(ppcor)

#Loading data
Datos <- read.csv2("ElasticModulus.csv", sep = ";")  #Change here the name of the file
head(Datos)
str(Datos)

#Data visualization
qplot(x = PMDTA, y = G, geom = "point", data = Datos)

#Variable as factor for the ANOVA
Datos$PMDTA_Factor <- as.factor(Datos$PMDTA)
Datos$G_Factor <- as.factor(Datos$G)
str(Datos)

#One way ANOVA
anova <- aov(G ~ PMDTA_Factor, data = Datos)
summary(anova)
