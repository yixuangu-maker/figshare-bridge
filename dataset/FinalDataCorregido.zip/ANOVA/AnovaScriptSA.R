#Two way ANOVA with R by Alejandro Moltó

#Loading libraries:
library(readr)
library(ggplot2)
library(dplyr)
library(multcompView)
library(ppcor)

#Loading data
Datos <- read.csv2("SwellingAcelerante.csv", sep = ";")  #Change here the name of the file
head(Datos)
str(Datos)

#Data visualization
qplot(x = pH, y = Swelling, geom = "point", data = Datos) +
  facet_grid(.~Acelerante, labeller = label_both)

#Variable as factor for the ANOVA
Datos$Acelerante_Factor <- as.factor(Datos$Acelerante)
Datos$pH_Factor <- as.factor(Datos$pH)
str(Datos)

#Two way ANOVA
anova <- aov(Swelling ~ Acelerante_Factor*pH_Factor, data = Datos)
summary(anova)


