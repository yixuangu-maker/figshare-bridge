#Two way ANOVA with R by Alejandro Moltó

#Loading libraries:
library(readr)
library(ggplot2)
library(dplyr)
library(multcompView)
library(ppcor)

#Loading data
Datos <- read.csv2("YoungCrosslinker.csv", sep = ";")  #Change here the name of the file
head(Datos)
str(Datos)

#Data visualization
qplot(x = Concentracion, y = Young, geom = "point", data = Datos) +
  facet_grid(.~Crosslinker, labeller = label_both)

#Variable as factor for the ANOVA
Datos$Crosslinker <- as.factor(Datos$Crosslinker)
Datos$Concentracion_Factor <- as.factor(Datos$Concentracion)
str(Datos)

#Two way ANOVA
anova <- aov(Young ~ Crosslinker*Concentracion_Factor, data = Datos)
summary(anova)


