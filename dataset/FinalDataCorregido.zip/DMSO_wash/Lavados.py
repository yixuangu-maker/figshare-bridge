import pandas as pd
import matplotlib.pyplot as plt

archivo = "DMSO_py.xlsx" # Nombre del archivo Excel

hoja1 = "Lavado 1" # Nombres de las hojas 
hoja2 = "Lavado 8"
hoja3 = "CA"
hoja4 = "CM"
hoja5 = "CB"


df1 = pd.read_excel(archivo, sheet_name=hoja1) # Leer cada hoja
df2 = pd.read_excel(archivo, sheet_name=hoja2)
df3 = pd.read_excel(archivo, sheet_name=hoja3)
df4 = pd.read_excel(archivo, sheet_name=hoja4)
df5 = pd.read_excel(archivo, sheet_name=hoja5)


x1, y1, err1 = df1.iloc[:,0], df1.iloc[:,1], df1.iloc[:,2] # Extraer columnas 
x2, y2, err2 = df2.iloc[:,0], df2.iloc[:,1], df2.iloc[:,2]
x3, y3 = df3.iloc[:,0], df3.iloc[:,1]
x4, y4 = df4.iloc[:,0], df4.iloc[:,1]
x5, y5= df5.iloc[:,0], df5.iloc[:,1]


plt.figure(figsize=(8,6)) # Crear la figura


plt.plot(x1, y1, # Representación con sombreado del error
         color='tab:blue', 
         marker= 'none', 
         linestyle='-', 
         label='DMSO signal after first wash')

plt.fill_between(x1, y1 - err1, y1 + err1, 
                 color='tab:blue', alpha=0.2)

plt.plot(x2, y2, 
         color='tab:red', 
         marker='none', 
         linestyle='-', 
         label='DMSO signal after last wash')

plt.fill_between(x2, y2 - err2, y2 + err2, 
                 color='tab:red', alpha=0.2)

plt.plot(x3, y3, 
         color='tab:grey', 
         marker='none', 
         linestyle='--', 
         label='1mL DMSO / 50mL deionized water')

plt.plot(x5, y5, 
         color='tab:green', 
         marker='none', 
         linestyle='--', 
         label='0.01mL DMSO / 50mL deionized water')

plt.xlim(210, 280)
plt.ylim(0, 3)



plt.title("DMSO removal signal")
plt.xlabel("Wavelength (nm)")
plt.ylabel("Intensity (a.u.)")


plt.legend()


plt.grid(True, alpha=0.3)

plt.savefig("DMSO_signal.pdf", dpi=300)
plt.savefig("DMSO_signal.svg", dpi=300)
plt.savefig("DMSO_signal.tiff", dpi=300)

plt.show()

