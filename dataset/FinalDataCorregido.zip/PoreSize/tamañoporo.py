import pandas as pd
import matplotlib.pyplot as plt


archivo_excel = "datos_poros.xlsx"   
nombres_hojas = ["PEGDA250", "PEGDA700", "1,3 Gly"]  

tick_size = 16


datos = [pd.read_excel(archivo_excel, sheet_name=hoja) for hoja in nombres_hojas]


plt.figure(figsize=(12, 8))

medias = []

for i, df in enumerate(datos):
    columna = df.iloc[:, 0]  
    media = columna.mean()
    medias.append(media)

    plt.subplot(2, 2, i+1)
    plt.hist(columna, bins=20, color="steelblue", edgecolor="black")
    plt.title(f"Pore size distribution for {nombres_hojas[i]}", fontsize=18)
    plt.xlabel("Pore size ($\\mu$m)", fontsize=18)
    plt.ylabel("Absolute frequency", fontsize=18)


    plt.xticks(fontsize=tick_size)
    plt.yticks(fontsize=tick_size)

plt.tight_layout()
plt.show()


for hoja, media in zip(nombres_hojas, medias):
    print(f"Tamaño de poro medio en {hoja}: {media:.3f}")
