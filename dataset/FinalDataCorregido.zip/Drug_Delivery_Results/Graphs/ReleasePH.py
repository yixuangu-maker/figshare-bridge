import pandas as pd
import matplotlib.pyplot as plt


excel_file = "Cin4.xlsx"


sheet_data1 = 0
sheet_data2 = 1


fig_width = 8
fig_height = 6
x_min = 0
x_max = 25
y_min = 0
y_max = 80


color_linea_1 = "blue"
color_puntos_1 = "darkblue"
color_error_1 = "darkblue"
marker_style_1 = "o"
line_style_1 = ""
line_width_1 = 1
marker_size_1 = 6
label_1 = ""


color_linea_2 = "orange"
color_puntos_2 = "darkorange"
color_error_2 = "darkorange"
marker_style_2 = "s"
line_style_2 = ""
line_width_2 = 1
marker_size_2 = 6
label_2 = ""



titulo = ""
titulo_size = 16
label_y = "Cummulative DOX released (%)"
label_x = "Time (h)"
label_size = 20
tick_size = 12
font_family = "Arial"


usar_leyenda = True

leyenda_4 = "pH 4"
leyenda_7 = "pH 7"


leyenda_loc = "upper left"
leyenda_size = 14


usar_grid = True
grid_style = "-"
grid_alpha = 0.4


df1 = pd.read_excel(excel_file, sheet_name=sheet_data1)
df2 = pd.read_excel(excel_file, sheet_name=sheet_data2)

x1, y1, err1 = df1.iloc[:, 0], df1.iloc[:, 1], df1.iloc[:, 2]
x2, y2, err2 = df2.iloc[:, 0], df2.iloc[:, 1], df2.iloc[:, 2]


plt.figure(figsize=(fig_width, fig_height))


plt.errorbar(
    x1, y1, yerr=err1,
    fmt=marker_style_1,
    markersize=marker_size_1,
    color=color_puntos_1,
    ecolor=color_error_1,
    elinewidth=1.2,
    capsize=4,
    label=leyenda_4,
)
plt.plot(x1, y1, line_style_1, color=color_linea_1, linewidth=line_width_1)


plt.errorbar(
    x2, y2, yerr=err2,
    fmt=marker_style_2,
    markersize=marker_size_2,
    color=color_puntos_2,
    ecolor=color_error_2,
    elinewidth=1.2,
    capsize=4,
    label=leyenda_7,
)
plt.plot(x2, y2, line_style_2, color=color_linea_2, linewidth=line_width_2)


if x_min is not None and x_max is not None:
    plt.xlim(x_min, x_max)
if y_min is not None and y_max is not None:
    plt.ylim(y_min, y_max)


plt.title(titulo, fontsize=titulo_size, fontfamily=font_family)
plt.xlabel(label_x, fontsize=label_size, fontfamily=font_family)
plt.ylabel(label_y, fontsize=label_size, fontfamily=font_family)
plt.xticks(fontsize=tick_size, fontfamily=font_family)
plt.yticks(fontsize=tick_size, fontfamily=font_family)
plt.xticks(fontsize=18)
plt.yticks(fontsize=18)


if usar_leyenda:
    plt.legend(fontsize=leyenda_size, loc=leyenda_loc)


if usar_grid:
    plt.grid(True, linestyle=grid_style, alpha=grid_alpha)

plt.tight_layout()
plt.savefig("release_ph.pdf", dpi=300)
plt.savefig("release_ph.svg", dpi=300)
plt.savefig("release_ph.tiff", dpi=300)
plt.show()
