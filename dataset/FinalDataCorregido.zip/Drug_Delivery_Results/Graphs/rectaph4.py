import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


excel_file = "Aph4.xlsx"
sheet_data1 = 0

fig_width = 8
fig_height = 6
x_min = 0
x_max = 42.5
y_min = 0
y_max = 1.2


color_linea_1 = "blue"
color_puntos_1 = "darkblue"
color_error_1 = "darkblue"
marker_style_1 = "o"
line_style_1 = None
line_width_1 = 1
marker_size_1 = 6


usar_leyenda = True

leyenda_puntos = "Experimental absorbance"
leyenda_recta = "y = 0.0263·x + 0.0024 /   R$^{2}$ = 0.999"


leyenda_loc = "upper left"
leyenda_size = 14


titulo = ""
titulo_size = 16
label_y = "Absorbance at 274 nm"
label_x = "DOX concentration (mg/L)"
label_size = 20
tick_size = 12
font_family = "Arial"


usar_grid = True
grid_style = "-"
grid_alpha = 0.4


df1 = pd.read_excel(excel_file, sheet_name=sheet_data1)
x1, y1, err1 = df1.iloc[:, 0], df1.iloc[:, 1], df1.iloc[:, 2]


plt.figure(figsize=(fig_width, fig_height))


plt.errorbar(
    x1, y1, yerr=err1,
    fmt=marker_style_1,
    markersize=marker_size_1,
    color=color_puntos_1,
    ecolor=color_error_1,
    elinewidth=1.2,
    capsize=4,
    label=leyenda_puntos
)

if line_style_1 is not None:
    plt.plot(
        x1, y1,
        linestyle=line_style_1,
        color=color_linea_1,
        linewidth=line_width_1
    )


m = 0.026350294
b = 0.002372414

x_line = np.linspace(x_min, x_max, 200)
y_line = m * x_line + b

plt.plot(
    x_line, y_line,
    color="red",
    linestyle="-",
    linewidth=2,
    label=leyenda_recta
)


plt.xlim(x_min, x_max)
plt.ylim(y_min, y_max)

plt.title(titulo, fontsize=titulo_size, fontfamily=font_family)
plt.xlabel(label_x, fontsize=label_size, fontfamily=font_family)
plt.ylabel(label_y, fontsize=label_size, fontfamily=font_family)

plt.xticks(fontsize=18, fontfamily=font_family)
plt.yticks(fontsize=18, fontfamily=font_family)

if usar_leyenda:
    plt.legend(fontsize=leyenda_size, loc=leyenda_loc)

if usar_grid:
    plt.grid(True, linestyle=grid_style, alpha=grid_alpha)

plt.tight_layout()
plt.savefig("calibrationph4.pdf", dpi=300)
plt.savefig("calibrationph4.svg", dpi=300)
plt.savefig("calibrationph4.tiff", dpi=300)
plt.show()