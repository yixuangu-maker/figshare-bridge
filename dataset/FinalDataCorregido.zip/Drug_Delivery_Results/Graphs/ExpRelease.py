import pandas as pd
import matplotlib.pyplot as plt


excel_file = "graph9.xlsx"


sheet_data1 = 0
sheet_data2 = 1
sheet_data3 = 2


fig_width = 8
fig_height = 6
x_min = 0
x_max = 27
y_min = 0
y_max = 100


color_linea_1 = "blue"
color_puntos_1 = "darkblue"
color_error_1 = "darkblue"
marker_style_1 = "o"
line_style_1 = "-"
line_width_1 = 1
marker_size_1 = 6
label_1 = ""


color_linea_2 = "red"
color_puntos_2 = "darkred"
color_error_2 = "darkred"
marker_style_2 = "^"
line_style_2 = "-"
line_width_2 = 1
marker_size_2 = 6
label_2 = ""


color_linea_3 = "green"
color_puntos_3 = "darkgreen"
color_error_3 = "darkgreen"
marker_style_3 = "v"
line_style_3 = "-"
line_width_3 = 1.5
marker_size_3 = 6
label_3 = ""


titulo = ""
titulo_size = 16
label_x = "Time (h)"
label_y = "Cummulative DOX released (%)"
label_size = 20
tick_size = 12
font_family = "Arial"


usar_leyenda = True

leyenda_o4 = "DOX release kinetics: pH 4"
leyenda_o7 = "Oral intake: pH 4"
leyenda_4= "Oral intake: pH 7"



leyenda_loc = "upper left"
leyenda_size = 14


usar_grid = True
grid_style = "-"
grid_alpha = 0.4


df1 = pd.read_excel(excel_file, sheet_name=sheet_data1)
df2 = pd.read_excel(excel_file, sheet_name=sheet_data2)
df3 = pd.read_excel(excel_file, sheet_name=sheet_data3)

x1, y1, err1 = df1.iloc[:, 0], df1.iloc[:, 1], df1.iloc[:, 2]
x2, y2, err2 = df2.iloc[:, 0], df2.iloc[:, 1], df2.iloc[:, 2]
x3, y3, err3 = df3.iloc[:, 0], df3.iloc[:, 1], df3.iloc[:, 2]



plt.figure(figsize=(fig_width, fig_height))


plt.errorbar(
    x1, y1, yerr=err1,
    fmt=marker_style_1,
    markersize=marker_size_1,
    color=color_puntos_1,
    ecolor=color_error_1,
    elinewidth=1.2,
    capsize=4,
    label=leyenda_o4,
)
if line_style_1 not in [None, "", "none", "None"]:
    plt.plot(x1, y1, line_style_1, color=color_linea_1, linewidth=line_width_1)


plt.errorbar(
    x2, y2, yerr=err2,
    fmt=marker_style_2,
    markersize=marker_size_2,
    color=color_puntos_2,
    ecolor=color_error_2,
    elinewidth=1.2,
    capsize=4,
    label=leyenda_o7,
)
if line_style_2 not in [None, "", "none", "None"]:
    plt.plot(x2, y2, line_style_2, color=color_linea_2, linewidth=line_width_2)


plt.errorbar(
    x3, y3, yerr=err3,
    fmt=marker_style_3,
    markersize=marker_size_3,
    color=color_puntos_3,
    ecolor=color_error_3,
    elinewidth=1.2,
    capsize=4,
    label=leyenda_4,
)
if line_style_3 not in [None, "", "none", "None"]:
    plt.plot(x3, y3, line_style_3, color=color_linea_3, linewidth=line_width_3)


plt.xlim(x_min, x_max)
plt.ylim(y_min, y_max)


plt.title(titulo, fontsize=titulo_size, fontfamily=font_family)
plt.xlabel(label_x, fontsize=label_size, fontfamily=font_family)
plt.ylabel(label_y, fontsize=label_size, fontfamily=font_family)
plt.xticks(fontsize=18)
plt.yticks(fontsize=18)


if usar_leyenda:
    plt.legend(fontsize=leyenda_size, loc=leyenda_loc)


if usar_grid:
    plt.grid(True, linestyle=grid_style, alpha=grid_alpha)

plt.tight_layout()
plt.savefig("experiment_drug_release.pdf", dpi=300)
plt.savefig("experiment_drug_release.svg", dpi=300)
plt.savefig("experiment_drug_release.tiff", dpi=300)
plt.show()
